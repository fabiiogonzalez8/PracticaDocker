<?php
define('base_url',getenv('BASE_URL'));
define('host', getenv('DB_HOST'));
define('db', getenv('DB_NAME'));
define('user', getenv('DB_USER'));
define('pass', getenv('DB_PASS'));
?>
